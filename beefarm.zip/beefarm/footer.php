 <!-- Footer -->
          <footer>
            <div class="container">
              <br>
              <div class="row text-center">
                <div class="col-md-12">
                  <p class="text-white">&copy; Copyright2018 || built by. <a href="https://www.facebook.com/fariesdevlay" target="blank" >CodeX Team</a></p>
                </div>
            </div>
            <div class="row text-center">
              <div class="col-md-12">
                  <a href="https://www.instagram.com/farisisalman07/"class="btn" target="blank">Instagram</a>
              </div>
            </div>
            </div>
          </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo "$url"; ?>view/myjs/jquery-3.2.1.slim.min.js"></script>
    <script src="<?php echo "$url"; ?>view/myjs/popper.min.js"></script>
    <script src="<?php echo "$url"; ?>view/js/bootstrap.min.js"></script>
    <script src="<?php echo "$url"; ?>view/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo "$url"; ?>view/myjs/js.js"></script>
    <script src="<?php echo "$url"; ?>view/myjs/sweetalert.min.js"></script>
    
  </body>
</html>