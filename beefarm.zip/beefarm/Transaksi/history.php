<?php 
	require'../header.php';
	if (isset($_SESSION["sudahLogin"])) {
		$data = query("SELECT * FROM ");
	}
 ?>
 	<section id="history" class="history">
 		<div class="container">
 			<div class="row">
 				<div class="col-md-12 text-center mt-5">
 					<span class="list-pembelian"> ---- List Pembelian ---- </span>
 				</div>
 			</div>
 			<div class="row">
 				<div class="col-md-12">
 					<div class="table-responsive-md">
 					<table class="table">
 						<thead class="bg-success">
 							<tr>
	 							<th>Nama Produk</th>
	 							<th>Tanggal Transaksi</th>
	 							<th>Event</th>
	 							<th>harga</th>
	 							<th>Kuantitas</th>
	 							<th>Total</th>
	 							<th>Pembayaran</th>
	 							<th>Aksi</th>
	 							<th>Status</th>
 							</tr>
 						</thead>
 						<tbody>
 							<tr>
 								<td></td>
 							</tr>
 						</tbody>
 					</table>
 					</div>
 				</div>
 			</div>
 		</div>
 		
 	</section>
 <?php 
 	require'../footer.php';
  ?>