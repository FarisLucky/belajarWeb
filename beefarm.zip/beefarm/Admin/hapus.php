<?php 
	$hapusProduk = query("SELECT * FROM tbl_produk WHERE id_produk = '$_GET[id]'");
	$foto = $hapusProduk[0]["foto"];
	if (file_exists("../foto_produk/$foto")) {
		unlink("../foto_produk/$foto");
	}

	$delete = mysqli_query($koneksi,"DELETE FROM tbl_produk WHERE id_produk='$_GET[id]'");
	if ($delete == true) {
		echo "<script>alert('Data diHapus Gan');</script>";
		echo "<script>location='index.php?halaman=produk'</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus Gan'); window.location=''</script>";
	}
 ?>