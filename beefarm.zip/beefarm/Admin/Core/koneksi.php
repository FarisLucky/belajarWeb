 <?php 
 	$db = "beefarm";
  $koneksi = mysqli_connect("localhost","root","",$db) or die(mysql_error());
  $base_url = "http://localhost/AdminLTE-2.4.5/";

  function query($database){
  	global $koneksi;
  	$konek = mysqli_query($koneksi,$database);
  	$rows = [];
  	while ($row = mysqli_fetch_assoc($konek)) {
  		$rows[] = $row;
  	}
  	return $rows;
  }


 // Produk
 function perbaruiProduk($method,$file_foto){
  global $koneksi;
    $namaProduk = ucwords(mysqli_escape_string($koneksi,$method["Nama_produk"]));
    $deskripsi = mysqli_escape_string($koneksi,$method["deskripsi"]);
    $berat = mysqli_escape_string($koneksi,$method["berat"]);
    $harga = mysqli_escape_string($koneksi,$method["harga"]);
    $stok = mysqli_escape_string($koneksi,$method["stok"]);
    $event = $method["event"];
    $nama_foto = $file_foto['name'];
    $lokasi_foto = $file_foto['tmp_name'];
    // jika tidak kosong lokasi foto sementara
    if (!empty($lokasi_foto)) {
      move_uploaded_file($lokasi_foto,"../foto_produk/".$nama_foto);  
      $sql = "UPDATE tbl_produk set nama_produk='$namaProduk', deskripsi = '$deskripsi',berat='$berat',foto='$nama_foto',harga='$harga',stok='$stok',id_event='$event' WHERE id_produk='$_GET[id]'";
      $result = mysqli_query($koneksi,$sql);
    }
    else{
    $sql = "UPDATE tbl_produk set nama_produk='$namaProduk', deskripsi = '$deskripsi',berat='$berat',harga='$harga',stok='$stok',id_event='$event' WHERE id_produk='$_GET[id]'";
      $result = mysqli_query($koneksi,$sql);  
    }
    
    return $result;
 }
  function tambahProduk($method,$file_foto){
    global $koneksi;
    $namaProduk = ucwords(mysqli_escape_string($koneksi,$method["Nama_produk"]));
    $deskripsi = mysqli_escape_string($koneksi,$method["deskripsi"]);
    $berat = mysqli_escape_string($koneksi,$method["berat"]);
    $harga = mysqli_escape_string($koneksi,$method["harga"]);
    $stok = mysqli_escape_string($koneksi,$method["stok"]);
    $event = $method["event"];
    $nama_foto = $file_foto['name'];
    $lokasi_foto = $file_foto['tmp_name'];
    move_uploaded_file($lokasi_foto,"../foto_produk/".$nama_foto);

    $sql = "INSERT INTO tbl_produk(nama_produk,deskripsi,berat,foto,harga,stok,id_event) VALUES('$namaProduk','$deskripsi','$berat','$nama_foto','$harga','$stok','$event')";
    $result = mysqli_query($koneksi,$sql);
    return mysqli_affected_rows($koneksi);
 }
  ?>
  