<div class="anggota" id="anggota">
<h2 class="m-4">
    Data pembelian
    <small>Control Pembelian</small>
</h2>
<br>
<table class="table table-bordered table-hover">
	<thead class="bg-primary">
		<th>No</th>
		<th>Nama Pemesan</th>
		<th>Tanggal</th>
		<th>Total Pembelian</th>
		<th>Alamat Pengiriman</th>
		<th>Status</th>
		<th>Aksi</th>
		</thead>
	<tbody>
		<?php 
			$dataPembelian = query("SELECT * FROM tbl_pembelian INNER JOIN tbl_anggota ON tbl_pembelian.id_anggota = tbl_anggota.id_anggota");
		 	foreach ($dataPembelian as $pembelian) {	
		 	$no = "1";	 
		 ?>
		<tr>
			<td><?= $no; ?></td>
			<td><?= $pembelian["nama_lengkap"]; ?></td>
			<td><?= $pembelian["tgl_pembelian"]; ?></td>
			<td><?= $pembelian["total_pembelian"]; ?></td>
			<td><?= $pembelian["alamat_pengiriman"]; ?></td>
			<td><?= $pembelian["status"]; ?></td>
			<td>
				<a href="index.php?halaman=detail&id=<?= $pembelian["id_pembelian"]; ?>" class="btn btn-danger btn-sm" name="detail">Detail</a>
			</td>
		</tr>
		<?php 
			$no++;
			} ?>
	</tbody>
</table>
<!-- Modal Detail -->
		<div class="modal fade " id="modal_detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLongTitle">Detail Pembelian<small><?= $dataPembelian[0]["nama_lengkap"] ?></small></h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <?php
					$detailPembelian = query("SELECT * FROM detail_pembelian INNER JOIN tbl_pembelian ON detail_pembelian.id_pembelian = tbl_pembelian.id_pembelian INNER JOIN tbl_produk ON detail_pembelian.id_produk = tbl_produk.id_produk WHERE tbl_pembelian.id_pembelian = 
						'$_GET[id]'");
				 		?>
                  <div class="modal-body">
                    <div class="detail" id="detail">
						<h4 class="text-center">Pembelian Daging</h4>
						<table class="table table-bordered table-responsive">
							<thead class="bg-primary">
								<th>No</th>
								<th>Nama</th>
								<th>Nama Produk</th>
								<th>Harga</th>
								<th>Jumlah</th>
							</thead>
							<?php 
								
								foreach ($detailPembelian as $beli) {
							 	$nomer="1";
							 ?>
							<tbody>
								<tr>
									<td><?= $nomer;  ?></td>
									<td><?= $beli["nama_lengkap"];  ?></td>
									<td><?= $beli["nama_produk"];  ?></td>
									<td><?= $beli["harga"]; ?></td>
									<td><?= $beli["jumlah"]  ?></td>
								</tr>
							</tbody>
								<?php
								$nomer++;
								 	}
								 ?>
						</table>
					</div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>

</div>