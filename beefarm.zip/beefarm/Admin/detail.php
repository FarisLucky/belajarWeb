	<?php
			$detailPembelian = query("SELECT * FROM tbl_pembelian INNER JOIN tbl_anggota ON tbl_pembelian.id_anggota = tbl_anggota.id_anggota WHERE tbl_pembelian.id_pembelian = '$_GET[id]'");
		 ?>
	<div class="detail" id="detail">
		<div class="row">
			<div class="col-md-12"">
				<div class="col-sm-8">
					<h2 class="">Detail Pembelian<small>Daging</small></h2>		
				</div>
				<div class="col-sm-4">
					<a href="index.php?halaman=pembelian" class="btn btn-warning kembali">Kembali</a>
				</div>
			</div>
		</div>
		<div class="row col-md-12">
			<table class="col-md-12 struk">
				<tr>
					<td>Nama Pembeli</td>
					<td width="30px">:</td>
					<td><?= $detailPembelian[0]["nama_lengkap"] ?></td>
					<td width="150px"></td>
					<td>Tanggal Transaksi</td>
					<td width="30px">:</td>
					<td><?= $detailPembelian[0]["tgl_pembelian"]  ?></td>
				</tr>
				<tr>
					<td>Alamat</td>
					<td>:</td>
					<td><?= $detailPembelian[0]["alamat"]; ?></td>
					<td width="150px"></td>
					<td>Kecamatan</td>
					<td>:</td>
					<td><?= $detailPembelian[0]["kecamatan"];?></td>
				</tr>
				<tr>
					<td colspan="4"></td>
					<td>Kabupaten</td>
					<td>:</td>
					<td><?= $detailPembelian[0]["kabupaten"];?></td>
				
				</tr>
				<tr>
					<td>email</td>
					<td>:</td>
					<td><?= $detailPembelian[0]["email"]; ?></td>
					<td width="150px"></td>
					<td>No Telp</td>
					<td>:</td>
					<td><?= $detailPembelian[0]["no_telp"];  ?></td>
				</tr>
				<tr>
					<td><b class="status">Status</b></td>
					<td>:</td>
					<?php 
						if ($detailPembelian[0]["status"] == "Pending") {
					?>
						<td><i class="fa fa-exclamation-triangle text-primary">&nbsp;<b>Pending</b></i></td>
					<?php
						}
						else{
					?>
						<td><i class="fa fa-check text-primary"><b class="status">Success</b></i></td>
					<?php
						}
					 ?>
					<td width="150px;"></td>
					<td></td>
				</tr>

			</table>
		</div>
	<table class="table table-bordered table-responsive">
		<?php
			$detailPembelian = query("SELECT * FROM detail_pembelian INNER JOIN tbl_pembelian ON detail_pembelian.id_pembelian = tbl_pembelian.id_pembelian
				INNER JOIN tbl_produk ON detail_pembelian.id_produk = tbl_produk.id_produk WHERE tbl_pembelian.id_pembelian = 
				'$_GET[id]'");
			$no = "1";
			foreach ($detailPembelian as $detail) {
				?>
		<thead class="bg-primary">
			<th>No</th>
			<th>Nama Produk</th>
			<th>Harga</th>
			<th>Jumlah</th>
		</thead>
		<tbody>
			<tr>
				<td><?= $no; ?></td>
				<td><?= $detail["nama_produk"]; ?></td>
				<td><?= $detail["harga"]; ?></td>
				<td><?= $detail["jumlah"]; ?></td>
			</tr>
		</tbody>
		<?php
		$no++;
			}
			?>
	</table>
	</div>	 