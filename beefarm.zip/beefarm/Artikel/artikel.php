<?php 

include'../header.php';
 ?>
 <br>
 <section class="artikel" id="artikel">
 	<div class="container">
 		<h4 class="text-center py-3">------ Artikel ------</h4>
 		<div class="row my-2">
 			<div class="col-md-3 offset-1">
 				<img src="<?php echo $url ?>view/img/artikel/screenshot_2.png" class="" alt="">
 			</div>
 			<div class="col-md-8">
 				<h5 class="card-title">Racikan Sop daging sapi khas Nusantara Indonesia</h5>
 				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam quae perspiciatis nihil repellat eos, esse, ipsa est porro quis eaque nisi provident minus nemo non reprehenderit omnis temporibus ratione impedit!</p>
 				<a href="">Lihat Lengkap Artikel>></a>
 			</div>
 		</div>
 		<div class="row my-2">
 			<div class="col-md-3 offset-1">
 				<img src="<?php echo $url ?>view/img/artikel/screenshot_2.png" class="" alt="">
 			</div>
 			<div class="col-md-8">
 				<h5 class="card-title">Racikan Sop daging sapi khas Nusantara Indonesia</h5>
 				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam quae perspiciatis nihil repellat eos, esse, ipsa est porro quis eaque nisi provident minus nemo non reprehenderit omnis temporibus ratione impedit!</p>
 				<a href="">Lihat Lengkap Artikel>></a>
 			</div>
 		</div>
 		<div class="row my-2">
 			<div class="col-md-3 offset-1">
 				<img src="<?php echo $url ?>view/img/artikel/screenshot_2.png" class="" alt="">
 			</div>
 			<div class="col-md-8">
 				<h5 class="card-title">Racikan Sop daging sapi khas Nusantara Indonesia</h5>
 				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam quae perspiciatis nihil repellat eos, esse, ipsa est porro quis eaque nisi provident minus nemo non reprehenderit omnis temporibus ratione impedit!</p>
 				<a href="">Lihat Lengkap Artikel>></a>
 			</div>
 		</div>
 		<div class="row my-2">
 			<div class="col-md-3 offset-1">
 				<img src="<?php echo $url ?>view/img/artikel/screenshot_2.png" class="" alt="">
 			</div>
 			<div class="col-md-8">
 				<h5 class="card-title">Racikan Sop daging sapi khas Nusantara Indonesia</h5>
 				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam quae perspiciatis nihil repellat eos, esse, ipsa est porro quis eaque nisi provident minus nemo non reprehenderit omnis temporibus ratione impedit!</p>
 				<a href="">Lihat Lengkap Artikel>></a>
 			</div>
 		</div>
 	</div>
 </section>

 <?php 

 include'../footer.php';
  ?>