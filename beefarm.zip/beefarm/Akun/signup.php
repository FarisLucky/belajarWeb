<?php 
	
	include"../core/koneksi.php";
	if (isset($_POST["daftar"])) {
		if (insertDaftar($_POST) > 0) {
		 echo "<script> alert('DAta berhasil ditambahkan');</script>";
		 }
		else{
			echo "<script> alert('DAta Gagal ditambahkan');</script>";
		}
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="<?= $url_login; ?>view/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= $url_login; ?>view/style/style_login.css">
	<title>Login Page</title>
</head>
<body>
	<section class="daftar" id="daftar">
		<div class="container">
			<div class="row">
				<div class="col-md-8 offset-2 text-center mt-3">
				<h3>Beefarm</h3>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col-md-8 offset-2 text-center mt-1">
				<h4>kuY Daftar Yuk</h4>
			</div>
			</div>
			<div class="row">
				<div class="col-md-6 offset-3 px-5">
				<form action="" method="POST">
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Nama Lengkap" name="Nama" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Username" name="User" required>
					</div>
					<div class="form-check-inline col-md-3">
						<input type="radio" class="form-check-input" name="jenis_kelamin" id="radio1" value="laki-laki">
						<label for="radio1" class="form-check-label">Laki-Laki</label>
					</div>
					<div class="form-check-inline col-md-7">
						<input type="radio" class="form-check-input" name="jenis_kelamin" id="radio1" value="Perempuan">
						<label for="radio2" class="form-check-label">Perempuan</label>
					</div>
					<div class="form-row mt-2">
					<div class="form-group col-md-6">
						<input type="date"class="form-control" name="tgl_lahir">
					</div>
					<div class="form-group col-md-6">
						<input type="text"class="form-control" placeholder="Tempat Lahir" name="tempat" required="">
					</div>
					</div>
					<div class="form-group">
						<textarea class="form-control" placeholder="Alamat Lengkap" name="alamat" required=""></textarea>
					</div>
					<div class="form-row">
					<div class="form-group col-md-6">
						<input type="text" class="form-control" placeholder="Kecamatan" name="Kecamatan" required="">
					</div>
					<div class="form-group col-md-6">
						<input type="text" class="form-control" placeholder="Kabupaten" name="Kabupaten" required="">
					</div>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" name="telp" placeholder="No Telp" required="">
					</div>
					<div class="form-group">
						<input type="Email" class="form-control" name="Email" placeholder=" Alamat Email" required="">
					</div>

					<div class="form-row">
					<div class="form-group col-md-6">
						<input type="Password" class="form-control" name="Password" placeholder="Password" required="">
					</div>
					<div class="form-group col-md-6">
						<input type="Password" class="form-control" name="Password2" placeholder=" Ulangi Password" required="">
					</div>
					</div>
					<button type="submit" class="btn btn-success col-md-12" name="daftar">Daftar</button>
				</form>
				<p class="mt-1">Sudah Punya Akun ? <a href="login.php">Login Disini</a></p>
			</div>
			</div>
		</div>
	</section>
<!-- Script js -->
	<script src="<?= $url_login; ?>view/myjs/jquery-3.2.1.slim.min.js"></script>
    <script src="<?= $url_login; ?>view/myjs/popper.min.js"></script>
    <script src="<?= $url_login; ?>view/js/bootstrap.min.js"></script>
    <script src="<?= $url_login; ?>view/js/jquery-3.3.1.min.js"></script>
</body>
</html> 