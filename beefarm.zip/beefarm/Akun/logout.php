<?php 
session_start();
require"../core/koneksi.php";
$_SESSION = [];
session_unset();
session_destroy();
header("Location:../index.php");
exit;

 ?>