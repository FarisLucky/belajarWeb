
$(document).ready(function(){
  $("#masuk").click(function(){
      window.location.href= "akun/login.php";
    })
  $("#daftar").click(function(){
    window.location.href = "akun/signup.php";
  })
  $("#keluar").click(function(){
    window.location.href = "akun/logout.php";
  })
  $("#slides").carousel({
      interval:4000
    });
    // Enable Carousel Indicators
    $(".item1").click(function(){
        $("#slides").carousel(0);
    });
    $(".item2").click(function(){
        $("#slides").carousel(1);
    });
    $(".item3").click(function(){
        $("#slides").carousel(2);
    });
    $(".simpan").click(function(){
      swal("Hello world!");
    })
})


    // Header Navigasi
   window.onscroll = function() {myFunction()};

    var navbar = document.getElementById("navigasi");
    var sticky = navbar.offsetTop;

    function myFunction() {
      if (window.pageYOffset >= 30) {
        navbar.classList.add("fixed-top")
      } else {
        navbar.classList.remove("fixed-top");
      }
    }