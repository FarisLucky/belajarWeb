 <!-- Menu Produk -->
        <section class="menu_produk" id="menu_produk">
          <div class="container child_header">
            <div class="row">
              <div class="col-md-12 p-2">
                <a href="" class="home">Home</a>
              </div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-md-3">
                <h5 class="custom_filter">------<img src="<?php echo $url ?>view/img/produk/filter.png" alt="">Filter Pencarian   ------</h5>
                <form action="" class="">
                  <select class="custom-select" name="" id="">
                    <option selected>Pilih Event</option>
                    <option value="Hari Raya Idul Fitri">Hari Raya Idul Fitri</option>
                    <option value="Hari Raya Idul Adha">Hari Raya Idul Adha</option>
                  </select>
                </form><br>
                <span>
                  <strong class="col-md-4">Filter Harga</strong>
                </span>
                <form action="">
                  <div class="input-group ">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="inputGroupPrepend2">Min</span>
                    </div>
                    <input type="text" class="form-control col-4" id="validationDefaultUsername" placeholder="Min" aria-describedby="inputGroupPrepend2" required>
                    <div class="input-group-prepend ml-4">
                      <span class="input-group-text" id="inputGroupPrepend2">Max</span>
                    </div>
                    <input type="text" class="form-control col-4" id="validationDefaultUsername" placeholder="Max" aria-describedby="inputGroupPrepend2" required>
                  </div>
                </form>
                <p><input type="hidden" class="price_range" value="0,500"></p>
                <button class="btn text-white filter" value="filter">Filter</button>
         </div>
         <div class="col-md-8 offset-1">
          <div class="row">
            <div class="col-md-12"> 
            <h5 class="custom_produk">------ Daftar Produk ------</h5>
            </div>
          </div>
          <!-- List Produk -->
          <div class="row">
                      <?php 
            $ambilFoto = query("SELECT * FROM tbl_produk");
            foreach ($ambilFoto as $foto) {
          ?>
            <div class="col-md-4">
              <div class="card">
                <img src="<?= $url ?>foto_produk/<?= $foto["foto"];  ?>" alt="" class="img-fluid rounded ">
                <div class="card-body">
                  <a href="#" class="card-title"><?= $foto["nama_produk"];  ?></a>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus iusto in, saepe, </p>
                    <small class="text-harga">Harga</small>
                    <p class="ml-5">Rp.<?= $foto["harga"];  ?></p>
                  </div>
                <div class="card-footer">
                  <a href="produk.php?halaman=detail&id=<?= $foto["id_produk"];  ?>" class="btn btn-primary">Detail</a>
                </div>
              </div>

            </div>
             <?php
            }
           ?>
           </div>
            </div>
          </div>
        </div> 
        </section>
        