 <section class="produk-detail mb-5" id="produk-detail">
 	<div class="container">
 		<div class="row my-2">
 			<div class="col-md-12 my-3">
 				<h4 class="text-center">---- Produk Detail ----</h4>
 			</div>
 		</div>
 		<div class="row">
 			<?php
 				$foto = query("SELECT * FROM tbl_produk INNER JOIN tbl_event ON tbl_produk.id_event = tbl_event.id_event WHERE id_produk = '$_GET[id]'");
 			?>
 				<div class="col-md-4 offset-1">
 					<img src="<?= $url ?>foto_produk/<?= $foto[0]["foto"];  ?>" alt="" class="img-thumbnail img-fluid">
 				</div>
 				<div class="col-md-6">
 					<div class="card">
 						<div class="card-header text-center">
 							<h3 class="card-title"><?= $foto[0]["nama_produk"];  ?></h3>
 						</div>
 						<div class="card-body">
 							<p><?= $foto[0]["deskripsi"]; ?></p>
 							<div class="col-md-12 desk-info">
 								<table>
 									<tr>
 										<td width="10%";>Harga</td>
 										<td width="10%";><small><?= $foto[0]["harga"];  ?></small></td>
 										<td width="40%";></td>
 										<td width="10%";>Stok</td>
 										<td width="10%";><small><?= $foto[0]["stok"];  ?></small></td>
 									</tr>
 									<tr>
 										<td width="10%";>Berat</td>
 										<td width="10%";><small><?= $foto[0]["berat"];  ?></small></td>
 										<td width="40%";></td>
 										<td width="10%";>Event</td>
 										<td width="20%";><small><?= $foto[0]["nama_event"];  ?></small></td>
 									</tr>
 								</table>
 							</div>
 						</div>
 						<div class="card-footer">
 							<button class="btn btn-danger col-md-12">Pesan</button>	
 						</div>
 					</div>
 			</div>
 		</div>
 	</div>
 </section>