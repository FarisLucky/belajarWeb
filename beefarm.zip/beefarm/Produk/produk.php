<?php 
  
  include"../header.php";
  if (isset($_GET["halaman"])) {
    if ($_GET["halaman"] == "detail") {
      include 'produk_detail.php';
    }
  }
  else{
    include 'tampil_produk.php';
  }
 ?>
       
        <!-- Tentang Kami -->
        <section class="tentang-kami mt-3 py-3" id="tentang-kami">
          <div class="container">
            <div class="container">
              <div class="row">
                <div class="col-md-2">
                  
                </div>
                <div class="col-md-3 pr-3 ">
                  <p>BeefFarm adalah sebuah toko online penjualan daging yang menjual macam macam daging sapi yang segar dan berkualitas dan halal dengan pemotongan yang nmenurut prosedur yang benar</p>
                </div>
                <div class="col-md-3 offset-1">
                  <span>ikuti Kami</span><br>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/facebook.png" alt="" class="ml-1 mt-1"></a>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/instagram.png" alt="" class="mt-1"></a>
                  <br>
                  <span>Hubungi Online</span><br>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/whatsapp.png" alt="" class="ml-1 mt-1"></a>
                </div>
                <div class="col-md-3">
                 <span>Pembayaran</span><br>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/bri.png" alt="" class="ml-5 mt-1"></a>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/bni.png" alt="" class="ml-2 mt-1"></a>
                  <a href=""><img src="<?php echo $url ?>view/img/produk/mandiri.png" alt="" class="ml-5 mt-1"></a>
                </div>
              </div>
            </div>
          </div>
        </section>
       <?php 

        include'../footer.php';
        ?>