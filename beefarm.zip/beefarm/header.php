<?php 
session_start();
    $url = "http://localhost/beefarm/";
    include "core/koneksi.php";
    if (!isset($_SESSION["sudahLogin"])) {
      $nama = "";
    } 
    else{
      $data = query("SELECT * FROM tbl_anggota WHERE id_anggota = '".$_SESSION['id_anggota']."'");
      $nama = $data[0]['username'];
    }
 ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="<?php echo "$url_login"; ?>view/css/bootstrap.min.css">
      <link rel="stylesheet" href="<?php echo "$url_login"; ?>view/style/style.css">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

    <title>Hello, world!</title>
  </head>
  <body>
      <!-- Header --> 
      <div class="header">
        <div class="judul d-none d-md-block d-sm-none pb-1">
          <ul class="ul1">
            <li>
              <a href=""><img src="<?php echo "$url_login"; ?>view/img/phone.png" alt="" class="phone"><span class="p-1">082213034131</span></a>
            </li>
            <li>
              <a href=""><img src="<?php echo "$url_login"; ?>view/img/email.png" alt="" class="phone"><span class="p-1">beefarmyuk@gmail.com</span></a>
            </li>
          </ul>
          <ul class="ul2">
            <?php 
              if (!empty($_SESSION["id_anggota"])) {
             ?>  
             <li id="loginUser">
              <a href=""><img src="<?php echo "$url_login" ?>view/img/user_index.png" alt=""><span class="p-1"><?= $nama; ?></span></a>
            </li>
            <?php 
              }
             ?>
            <li>
              <a href=""><img src="<?php echo "$url_login"; ?>view/img/notif.png" alt="" class="phone"><span class="p-1">Notification</span></a>
            </li>
            <li>
              <a href=""><img src="<?php echo "$url_login"; ?>view/img/help.png" alt="" class="phone"><span class="p-1">Bantuan</span></a>
            </li>
          </ul>
        </div>
          <nav class="navbar navbar-expand-md navbar-dark bg-white py-1" id="navigasi">
            <div class="container-fluid ">
            <a href="" class="navbar-brand">beefarm</a>
            <button class="navbar-toggler bg-dark" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarContent">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a href="<?php echo $url_login ?>index.php" class="nav-link ">Beranda</a></li>
                <li class="nav-item"><a href="<?php echo $url_login ?>Produk/Produk.php" class="nav-link ">Produk</a></li>
                <li class="nav-item"><a href="<?php echo $url_login ?>Artikel/artikel.php" class="nav-link ">Artikel</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link ">Galleri</a></li>
                <li class="nav-item"><a href="#contact" class="nav-link ">Hubungi Kami</a></li>
                <?php if(empty($_SESSION["id_anggota"])) {
                ?>
                  <li class="nav-item pl-1"><a href="<?= $url_login  ?>Akun/login.php" class="btn sign text-white" type="submit" id="masuk">Masuk</a></li>
                  <li class="nav-item pl-1"><a href="<?= $url_login  ?>Akun/signup.php" class="btn sign1 text-white" type="submit" id="daftar">Daftar</a></li>  
                <?php 
                  } 
                  else{
                 ?>
                  <li class="nav-item pl-1"><button class="btn sign text-white" type="submit" id="keluar">Keluar</button></li>  
                 <?php } ?>
              </ul>
              <ul class="navbar-nav nav2 mx-4">
                <a href=""><img src="<?php echo $url_login ?>view/img/cart.png" alt=""></a>
              </ul>
            </div>
            </div>  
          </nav>
        </div>