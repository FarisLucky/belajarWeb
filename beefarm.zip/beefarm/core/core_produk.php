<?php 

	include'koneksi.php';

	function insertProduk(){
		
	}
 ?>