<?php 
	
	// if (isset($_POST['submitin'])) {
	// 	$nama = $_POST["nama"];
	// 	$password = password_hash($nama,PASSWORD_DEFAULT);
	// 	echo password_verify($nama,$password);
	// 	echo $password;
	// }
	$input = "rofi";
	$hash = password_hash("rofi",PASSWORD_DEFAULT);
	echo"$hash<br>";
	echo password_verify($input,$hash);
 ?>
 <!-- <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Document</title>
 </head>
 <body>
 	<form action="" method="post">
 	<input type="text" name="nama">
 	<button name="submitin">kirim</button>
	</form>
 </body>
 </html> -->