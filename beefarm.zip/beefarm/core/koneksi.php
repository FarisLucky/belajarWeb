<?php 
	$db = "beefarm";
	$conn = mysqli_connect("localhost","root","",$db) or die(mysql_error());
	$url_login = "http://localhost/beefarm/";
	
function query($db){
	global $conn;
	$result = mysqli_query($conn,$db);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}

// Insert Daftar Anggota
function insertDaftar($data){
	global $conn;
	$nama	= ucfirst(mysqli_real_escape_string($conn,$data["Nama"]));
	$user	= strtolower(stripslashes($data["User"]));
	$jk		= mysqli_real_escape_string($conn,$data["jenis_kelamin"]);
	$tgl	= mysqli_real_escape_string($conn,$data["tgl_lahir"]);
	$tempat	= mysqli_real_escape_string($conn,$data["tempat"]);
	$alamat	= mysqli_real_escape_string($conn,$data["alamat"]);
	$kec	= mysqli_real_escape_string($conn,$data["Kecamatan"]);
	$Kab 	= mysqli_real_escape_string($conn,$data["Kabupaten"]);
	$telp	= mysqli_real_escape_string($conn,$data["telp"]);
	$email	= mysqli_real_escape_string($conn,$data["Email"]);
	$pass1	= mysqli_real_escape_string($conn,$data["Password"]);
	$pass2	= mysqli_real_escape_string($conn,$data["Password2"]);
	
	// Cek Username
	$result = mysqli_query($conn,"SELECT * FROM tbl_anggota WHERE username = '$user'");
	if (mysqli_fetch_assoc($result)) {
		echo"<script>alert('user Sudah Terdaftar !')</script>";
		return false;
	}
	// Cek Password
	if ($pass1 !== $pass2) {
		echo"<script>alert('Passw tidak Cocok !')</script>";
	return false;
	}

	$password = password_hash($pass1,PASSWORD_DEFAULT);
	
	$sql = "INSERT INTO tbl_anggota(nama_lengkap,jenis_kelamin,tgl_lahir,tempat_lahir,alamat,Kecamatan,Kabupaten,email,no_telp,username,password) VALUES('$nama','$jk','$tgl','$tempat','$alamat','$kec','$Kab','$email','$telp','$user','$password')";

	$result = mysqli_query($conn,$sql);

	return mysqli_affected_rows($conn);
}
function updateData($sessi){
	global $conn;
	$nama	= ucfirst(mysqli_real_escape_string($conn,$_POST["nama"]));
	$user	= strtolower(stripslashes($_POST["user"]));
	$email	= mysqli_real_escape_string($conn,$_POST["email"]);

	$update = "UPDATE tbl_anggota SET nama_lengkap ='$nama',Username = '$user',email = '$email' WHERE id_anggota = '$sessi'";
	$result = mysqli_query($conn,$update);
	return mysqli_affected_rows($conn);
}

// Menampilkan Detail Anggota

?>
